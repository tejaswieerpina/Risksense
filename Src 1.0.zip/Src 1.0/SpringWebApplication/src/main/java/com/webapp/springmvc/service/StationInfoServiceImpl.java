package com.webapp.springmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.webapp.springmvc.dao.StationInfoDAO;
import com.webapp.springmvc.model.StationInfoPOJO;

@Service("stationService")
@Transactional
public class StationInfoServiceImpl implements StationInfoService {

	@Autowired
	StationInfoDAO dao;
	
	public List<StationInfoPOJO> getAllEmployees() 
	{
		return dao.getAllStationInfo();
	}

	@Override
	public StationInfoPOJO findById(int id) {
		return dao.findById(id);
	}

	@Override
	public void saveStation(StationInfoPOJO stationObj) {
		dao.saveStation(stationObj);
		
	}
}
