package com.webapp.springmvc.service;

import java.util.List;

import com.webapp.springmvc.model.StationInfoPOJO;

public interface StationInfoService 
{
	public List<StationInfoPOJO> getAllEmployees();
	
	StationInfoPOJO findById(int id);
	
	void saveStation(StationInfoPOJO stationObj);
}
