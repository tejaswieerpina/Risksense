package com.webapp.springmvc.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;
import com.webapp.springmvc.model.StationInfoPOJO;

@Repository
public class StationInfoDAOImpl extends AbstractDAO<Integer, StationInfoPOJO>  implements StationInfoDAO {

	public List<StationInfoPOJO> getAllStationInfo() 
	{
		List<StationInfoPOJO> stationObj = new ArrayList<StationInfoPOJO>();
		
		StationInfoPOJO vo1 = new StationInfoPOJO();
		vo1.setSysId(1);
		vo1.setStationId("Station 1");
		vo1.setPrimaryPId("primaryPId 1");
		vo1.setAlertnatePId("alertnatePId 1");
		stationObj.add(vo1);
		
		StationInfoPOJO vo2 = new StationInfoPOJO();
		vo1.setSysId(2);
		vo1.setStationId("Station 2");
		vo1.setPrimaryPId("primaryPId 2");
		vo1.setAlertnatePId("alertnatePId 2");
		stationObj.add(vo2);

		
		return stationObj;
	}

	@Override
	public StationInfoPOJO findById(int id) {
		return getByKey(id);
	}

	@Override
	public void saveStation(StationInfoPOJO stationObj) {
		persist(stationObj);
		
	}

	@Override
	public void deleteStationBySysId(String sysId) {
		Query query = getSession().createSQLQuery("delete from StationInfoPOJO where sysId = :sysId");
        query.setString("sysId", sysId);
        query.executeUpdate();
		
	}

	@Override
	public List<StationInfoPOJO> findAllStations() {
		Criteria criteria = createEntityCriteria();
        return (List<StationInfoPOJO>) criteria.list();
	}

	@Override
	public StationInfoPOJO findStationBySysId(String sysId) {
		Criteria criteria = createEntityCriteria();
        criteria.add(Restrictions.eq("sysId", sysId));
        return (StationInfoPOJO) criteria.uniqueResult();
	}
}