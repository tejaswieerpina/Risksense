package com.webapp.springmvc.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.joda.time.LocalDate;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="LOCATION_INFO")
public class LocationInfoPOJO implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "sys_id", nullable = false)
	private Integer sysId;
	
	@Column(name = "station_sys_id", nullable = false)
	private Integer stationSysId;
	
	@Column(name = "ip_address", nullable = false)
	private String ipAddress;
	
	@Column(name = "office_id", nullable = false)
	private String officeId;
	
	@Column(name = "office_mnemonic", nullable = false)
	private String officeMnemonic;
	
	@Column(name = "l1_server_cd", nullable = false)
	private String l1ServerCd;
	
	@Column(name = "l1_server_sufx", nullable = false)
	private String l1ServerSufx;
	
	@Column(name = "business_object_desc", nullable = false)
	private String businessObjectDesc;
	
	
	@Column(name = "creator_Id", nullable = false)
	private String creatorId;
	
	@DateTimeFormat(pattern="dd/MM/yyyy") 
    @Column(name = "create_timestamp", nullable = false)
	private LocalDate createTimestamp;
	
	@Column(name = "modified_By", nullable = false)
	private String modifiedBy;
	
	@DateTimeFormat(pattern="dd/MM/yyyy") 
    @Column(name = "modified_timestamp", nullable = false)
	private LocalDate modifiedTimestamp;

	public Integer getSysId() {
		return sysId;
	}

	public void setSysId(Integer sysId) {
		this.sysId = sysId;
	}

	public Integer getStationSysId() {
		return stationSysId;
	}

	public void setStationSysId(Integer stationSysId) {
		this.stationSysId = stationSysId;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public String getOfficeId() {
		return officeId;
	}

	public void setOfficeId(String officeId) {
		this.officeId = officeId;
	}

	public String getOfficeMnemonic() {
		return officeMnemonic;
	}

	public void setOfficeMnemonic(String officeMnemonic) {
		this.officeMnemonic = officeMnemonic;
	}

	public String getL1ServerCd() {
		return l1ServerCd;
	}

	public void setL1ServerCd(String l1ServerCd) {
		this.l1ServerCd = l1ServerCd;
	}

	public String getL1ServerSufx() {
		return l1ServerSufx;
	}

	public void setL1ServerSufx(String l1ServerSufx) {
		this.l1ServerSufx = l1ServerSufx;
	}

	public String getBusinessObjectDesc() {
		return businessObjectDesc;
	}

	public void setBusinessObjectDesc(String businessObjectDesc) {
		this.businessObjectDesc = businessObjectDesc;
	}

	public String getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	public LocalDate getCreateTimestamp() {
		return createTimestamp;
	}

	public void setCreateTimestamp(LocalDate createTimestamp) {
		this.createTimestamp = createTimestamp;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public LocalDate getModifiedTimestamp() {
		return modifiedTimestamp;
	}

	public void setModifiedTimestamp(LocalDate modifiedTimestamp) {
		this.modifiedTimestamp = modifiedTimestamp;
	}

	@Override
	public String toString() {
		return "LocationInfoPOJO [sysId=" + sysId + ", stationSysId=" + stationSysId + ", ipAddress=" + ipAddress
				+ ", officeId=" + officeId + ", officeMnemonic=" + officeMnemonic + ", l1ServerCd=" + l1ServerCd
				+ ", l1ServerSufx=" + l1ServerSufx + ", businessObjectDesc=" + businessObjectDesc + "]";
	}

}
