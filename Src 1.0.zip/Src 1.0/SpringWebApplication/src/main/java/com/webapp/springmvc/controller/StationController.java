package com.webapp.springmvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.webapp.springmvc.model.StationInfoPOJO;
import com.webapp.springmvc.service.StationInfoService;

@Controller
@RequestMapping("/station-module/addNew")
@SessionAttributes("station")
public class StationController {
	
	@Autowired
	StationInfoService service;

	public StationController()
	{
		
	}

	@RequestMapping(method = RequestMethod.GET)
	public String setupForm(Model model) {
		StationInfoPOJO stationObj = new StationInfoPOJO();
		model.addAttribute("station", stationObj);
		return "addStationInfo";
	}

	@RequestMapping(method = RequestMethod.POST)
	public String submitForm(@ModelAttribute("station") StationInfoPOJO stationObj,
			BindingResult result, SessionStatus status,
	        final Model model, 
	        final RedirectAttributes redirectAttributes) {
		
		// Store the station information in database
		service.saveStation(stationObj);
		
		System.out.println(stationObj);

		redirectAttributes.addFlashAttribute("station1", stationObj);
		// Mark Session Complete
		status.setComplete();
		return "redirect:success";
	}

	@RequestMapping(value = "/success", method = RequestMethod.GET)
	public String success(Model model, @ModelAttribute("station1") StationInfoPOJO stationObj) {
		model.addAttribute("station", stationObj);
		return "addSuccess";
	}

}
