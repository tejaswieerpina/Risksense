package com.webapp.springmvc.dao;

import java.util.List;

import com.webapp.springmvc.model.LocationInfoPOJO;

public interface LocationInfoDAO {
	
	LocationInfoPOJO findById(int id);
	 
    void saveLocationInfo(LocationInfoPOJO locationObj);
    
    List<LocationInfoPOJO> findAllLocations();

}
