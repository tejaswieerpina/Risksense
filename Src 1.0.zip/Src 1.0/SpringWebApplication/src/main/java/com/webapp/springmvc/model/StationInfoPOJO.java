package com.webapp.springmvc.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.joda.time.LocalDate;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="STATION_INFO")
public class StationInfoPOJO implements Serializable 
{
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name = "sys_id", nullable = false)
	private Integer sysId;
	
	@Column(name = "station_id", nullable = false)
	private String stationId;
	
	@Column(name = "primary_PId", nullable = false)
	private String primaryPId;
	
	@Column(name = "alertnate_PId", nullable = false)
	private String alertnatePId;
	
	@Column(name = "creator_Id", nullable = false)
	private String creatorId;
	
	@DateTimeFormat(pattern="dd/MM/yyyy") 
    @Column(name = "create_timestamp", nullable = false)
	private LocalDate createTimestamp;
	
	@Column(name = "modified_By", nullable = false)
	private String modifiedBy;
	
	@DateTimeFormat(pattern="dd/MM/yyyy") 
    @Column(name = "modified_timestamp", nullable = false)
	private LocalDate modifiedTimestamp;
	
	public Integer getSysId() {
		return sysId;
	}

	public void setSysId(Integer sysId) {
		this.sysId = sysId;
	}

	public String getStationId() {
		return stationId;
	}

	public void setStationId(String stationId) {
		this.stationId = stationId;
	}

	public String getPrimaryPId() {
		return primaryPId;
	}

	public void setPrimaryPId(String primaryPId) {
		this.primaryPId = primaryPId;
	}

	public String getAlertnatePId() {
		return alertnatePId;
	}

	public void setAlertnatePId(String alertnatePId) {
		this.alertnatePId = alertnatePId;
	}
	
	public String getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	public LocalDate getCreateTimestamp() {
		return createTimestamp;
	}

	public void setCreateTimestamp(LocalDate createTimestamp) {
		this.createTimestamp = createTimestamp;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public LocalDate getModifiedTimestamp() {
		return modifiedTimestamp;
	}

	public void setModifiedTimestamp(LocalDate modifiedTimestamp) {
		this.modifiedTimestamp = modifiedTimestamp;
	}

	@Override
	public String toString() {
		return "StationInfoPOJO [sysId=" + sysId + ", stationId=" + stationId + ", primaryPId=" + primaryPId
				+ ", alertnatePId=" + alertnatePId + "]";
	}
	
}