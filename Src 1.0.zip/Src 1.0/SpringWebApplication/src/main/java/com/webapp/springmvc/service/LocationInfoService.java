package com.webapp.springmvc.service;

import java.util.List;

import com.webapp.springmvc.model.LocationInfoPOJO;

public interface LocationInfoService {
	
	LocationInfoPOJO findById(int id);
	
	void saveLocation(LocationInfoPOJO locationObj);
	
	List<LocationInfoPOJO> findAllLocations();

}
